function mostrarMensagem() {
  const mensagem = document.getElementById("mensagem");
  mensagem.textContent = "Você clicou no botão! Obrigado por visitar minha página.";
}
