# Página Web Simples

Este é um projeto simples de uma página web criado por **Andre Luiz Ribeiro de Castro** como parte de um exercício prático. A página utiliza HTML, CSS e JavaScript.

## Funcionalidades

- Estrutura HTML básica
- Estilização com CSS
- Interatividade com JavaScript

## Como visualizar

Você pode acessar a página diretamente pelo GitHub Pages ou abrir o `index.html` em um navegador.

## Autor

Andre Luiz Ribeiro de Castro - Fortaleza (CE)
